#include<iostream>
#include"Header.h"
using namespace std;

void main(){
	int n;
	cout << "\n\n\t\tENTER THE NUMBER: ";
	cin >> n;
	hello fac;
	cout << "\n\n\t\tTHE FACTORIAL IS: ";
	cout <<fac.factorial(n);
}