#include "stdafx.h"
#include "CppUnitTest.h"
#include"..\ConsoleApplication1\Source.cpp"


using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			// TODO: Your test code here
			hello object;
			Assert::AreEqual(120, object.factorial(5));
		}
		TEST_METHOD(TestMethod2)
		{
			// TODO: Your test code here
			hello object;
			Assert::AreNotEqual(710, object.factorial(6));
		}

	};
}