#include "stdafx.h"
#include "CppUnitTest.h"
#include"..\ConsoleApplication2\\Source.cpp"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			// TODO: Your test code here
			stack i;
			Assert::AreEqual(1, i.isEmpty());
		}
		TEST_METHOD(TestMethod2)
		{
			// TODO: Your test code here
			stack i;
			Assert::AreEqual(0, i.isFull());
		}
	};
}