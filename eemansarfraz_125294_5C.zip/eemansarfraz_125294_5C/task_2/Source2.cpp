#include<iostream>
#define SIZE 8
using namespace std;

class stack{

public:
	int arr[SIZE];
	int t;
	stack();
	int isEmpty();
	int isFull();
	int push(int);
	int pop();
	void display();
};

stack::stack(){
	t = -1;
}

int stack::isEmpty(){
	if (t == -1)
		return 1;
	else
		return 0;
}

int stack::isFull(){
	if (t == (SIZE - 1))
		return 1;
	else
		return 0;

}

int stack::push(int n){
	if (isFull())
	{
		return 0;
	}
	t++;
	arr[t] = n;
	return n;
}

int stack::pop(){
	int temp;
	if (isEmpty())
		return 0;
	temp = arr[t];
	return temp;
}

void stack::display(){
	int i;
	for (i = (t); i >= 0; i--)
		cout << arr[i] << " ";
	cout << endl;
}

void main(){

	stack i;
	i.push(5);
	i.push(6);
	i.push(74);
	i.push(8);
	i.push(9);
	i.push(94);
	i.push(10);
	i.push(22);
	i.display();
	cout << "\n\n\t\tELEMENT POPPED OUT OF THE STACK IS:  " << i.pop();
	getchar();



}